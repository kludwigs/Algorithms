#! /bin/bash
./prime_number.exe 100 1
./prime_number.exe 100 2
./prime_number.exe 100 3
./prime_number.exe 100 4
./prime_number.exe 1000 1
./prime_number.exe 1000 2
./prime_number.exe 1000 3
./prime_number.exe 1000 4
./prime_number.exe 10000 1
./prime_number.exe 10000 2
./prime_number.exe 10000 3
./prime_number.exe 10000 4
./prime_number.exe 100000 1
./prime_number.exe 100000 2
./prime_number.exe 100000 3
./prime_number.exe 100000 4